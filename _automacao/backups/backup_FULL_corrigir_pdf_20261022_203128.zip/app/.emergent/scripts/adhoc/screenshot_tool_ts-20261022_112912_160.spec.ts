import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errs: string[] = [];
page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
page.on('response', r => { if (r.status() >= 400 && !r.url().includes('/auth/me')) errs.push(r.status() + ' ' + r.url()); });
await page.setViewportSize({ width: 1440, height: 900 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.locator('input[type="email"]').fill('drigobh@gmail.com');
await page.locator('input[type="password"]').fill('Bravus@2026');
await page.locator('button[type="submit"]').click();
await page.waitForURL(u => !u.pathname.includes('login'), { timeout: 15000 });
await page.waitForTimeout(2500);
await page.screenshot({ path: '.screenshots/dash.png', type: 'jpeg' });
for (const p of ['/cadastros/veiculos', '/acoplamentos', '/abastecimentos', '/manutencoes', '/usuarios', '/auditoria', '/seguranca']) {
  await page.goto(p, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1800);
  const txt = (await page.locator('main').innerText().catch(() => '')).slice(0, 120).replace(/\n/g, ' | ');
  console.log(p, '=>', txt);
}
await page.goto('/acoplamentos', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2000);
await page.screenshot({ path: '.screenshots/acop.png', type: 'jpeg' });
console.log('ERRORS', JSON.stringify(errs));
});
