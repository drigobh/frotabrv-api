import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errs: string[] = [];
page.on('response', r => { if (r.status() >= 400 && !r.url().includes('/auth/me')) errs.push(r.status() + ' ' + r.url()); });
await page.setViewportSize({ width: 1440, height: 900 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.locator('input[type="email"]').fill('operador@bravus.com.br');
await page.locator('input[type="password"]').fill('Operador@2026');
await page.locator('button[type="submit"]').click();
await page.waitForURL(u => !u.pathname.includes('login'), { timeout: 15000 });
await page.goto('/acoplamentos', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2000);
console.log('before', await page.getByTestId('conjuntos-count').innerText());
await page.getByTestId('novo-acop-veiculo').click(); await page.getByTestId('novo-acop-veiculo-option-0').click();
await page.getByTestId('novo-acop-carreta').click(); await page.getByTestId('novo-acop-carreta-option-1').click();
await page.getByTestId('novo-acop-motorista').click(); await page.getByTestId('novo-acop-motorista-option-1').click();
await page.getByTestId('novo-acop-submit').click();
await page.waitForTimeout(2500);
console.log('after', await page.getByTestId('conjuntos-count').innerText());
console.log('excluir visible for operador:', await page.getByText('Excluir', { exact: true }).count());
console.log('usuarios nav:', await page.getByText('Usuários', { exact: true }).count());
await page.screenshot({ path: '.screenshots/op.png', type: 'jpeg' });
console.log('ERRORS', JSON.stringify(errs));
});
