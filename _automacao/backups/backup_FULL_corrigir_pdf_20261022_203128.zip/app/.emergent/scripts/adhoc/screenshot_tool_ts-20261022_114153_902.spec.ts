import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errs: string[] = [];
page.on('console', m => { if (m.type() === 'error' && !m.text().includes('401')) errs.push('console: ' + m.text()); });
page.on('response', r => { if (r.status() >= 400 && !r.url().includes('/auth/me')) errs.push(r.status() + ' ' + r.url()); });
await page.setViewportSize({ width: 1440, height: 900 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.locator('input[type="email"]').fill('drigobh@gmail.com');
await page.locator('input[type="password"]').fill('Bravus@2026');
await page.locator('button[type="submit"]').click();
await page.waitForURL(u => !u.pathname.includes('login'), { timeout: 15000 });
await page.waitForTimeout(2000);
console.log('alertas', await page.getByTestId('alertas-count').innerText());
// Documento
await page.getByTestId('nav-documentos').click();
await page.waitForTimeout(1500);
const antes = await page.getByTestId('documento-tab-todos').innerText();
await page.getByTestId('documento-new-button').click();
await page.getByTestId('documento-form-entidade-id').click(); await page.getByTestId('documento-form-entidade-id-option-0').click();
await page.getByTestId('documento-form-tipo').click(); await page.getByTestId('documento-form-tipo-option-3').click();
await page.getByTestId('documento-form-numero').fill('TAC-123');
await page.getByTestId('documento-form-validade').fill('2026-11-05');
await page.getByTestId('documento-form-submit').click();
await page.waitForTimeout(1500);
console.log('docs', antes, '->', await page.getByTestId('documento-tab-todos').innerText());
await page.screenshot({ path: '.screenshots/docs.png', type: 'jpeg' });
// Financeiro
await page.getByTestId('nav-financeiro').click();
await page.waitForTimeout(2500);
console.log('lucro', await page.getByTestId('fin-lucro-total').innerText());
await page.screenshot({ path: '.screenshots/fin.png', type: 'jpeg' });
await page.getByTestId('financeiro-tab-pagar').click();
await page.waitForTimeout(1500);
const t1 = await page.getByTestId('contas-pagar-tab-abertas').innerText();
await page.locator('[data-testid^="conta-baixa-"]').first().click();
await page.getByTestId('conta-baixa-confirm').click();
await page.waitForTimeout(1500);
console.log('abertas', t1, '->', await page.getByTestId('contas-pagar-tab-abertas').innerText());
// Ranking
await page.getByTestId('nav-ranking').click();
await page.waitForTimeout(2000);
console.log('ranking meta', await page.getByTestId('ranking-meta-valor').innerText(), 'batidas', await page.getByTestId('ranking-batidas').innerText());
await page.screenshot({ path: '.screenshots/rank.png', type: 'jpeg' });
// Relatorios
await page.getByTestId('nav-relatorios').click();
await page.waitForTimeout(1500);
await page.getByTestId('relatorio-periodo-preset-6m').click();
const [dl] = await Promise.all([page.waitForEvent('download'), page.getByTestId('relatorio-abastecimentos-pdf').click()]);
console.log('download', dl.suggestedFilename());
const [dl2] = await Promise.all([page.waitForEvent('download'), page.getByTestId('relatorio-acoplamentos-csv').click()]);
console.log('download', dl2.suggestedFilename());
await page.screenshot({ path: '.screenshots/rel.png', type: 'jpeg' });
console.log('ERRORS', JSON.stringify(errs));
});
