import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errs: string[] = [];
page.on('console', m => { if (m.type() === 'error' && !m.text().includes('401')) errs.push('console: ' + m.text()); });
page.on('response', r => { if (r.status() >= 400 && !r.url().includes('/auth/me')) errs.push(r.status() + ' ' + r.url()); });
await page.setViewportSize({ width: 1440, height: 900 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.locator('input[type="email"]').fill('drigobh@gmail.com');
await page.locator('input[type="password"]').fill('Bravus@2026');
await page.locator('button[type="submit"]').click();
await page.waitForURL(u => !u.pathname.includes('login'), { timeout: 15000 });
await page.goto('/ranking', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2500);
await page.getByTestId('galeria-campeoes').scrollIntoViewIfNeeded();
console.log('placar1', await page.getByTestId('placar-item-1').innerText());
console.log('set', await page.getByTestId('galeria-campeao-2026-09').innerText(), '|', await page.getByTestId('galeria-parabens-2026-09').innerText());
await page.screenshot({ path: '.screenshots/galeria.png', type: 'jpeg' });
await page.goto('/cadastros/motoristas', { waitUntil: 'domcontentloaded' });
await page.waitForTimeout(2000);
console.log('email col', await page.getByText('E-mail', { exact: true }).count());
console.log('ERRORS', JSON.stringify(errs));
});
