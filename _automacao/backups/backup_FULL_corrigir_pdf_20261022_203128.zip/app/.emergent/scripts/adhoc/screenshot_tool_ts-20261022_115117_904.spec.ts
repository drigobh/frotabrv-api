import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errs: string[] = [];
page.on('console', m => { if (m.type() === 'error' && !m.text().includes('401')) errs.push('console: ' + m.text()); });
page.on('response', r => { if (r.status() >= 400 && !r.url().includes('/auth/me')) errs.push(r.status() + ' ' + r.url()); });
await page.setViewportSize({ width: 1440, height: 900 });
await page.goto('/login', { waitUntil: 'domcontentloaded' });
await page.locator('input[type="email"]').fill('drigobh@gmail.com');
await page.locator('input[type="password"]').fill('Bravus@2026');
await page.locator('button[type="submit"]').click();
await page.waitForURL(u => !u.pathname.includes('login'), { timeout: 15000 });
await page.waitForTimeout(2500);
console.log('campeao', await page.getByTestId('campeao-nome').innerText(), '| lider', await page.getByTestId('lider-nome').innerText());
await page.getByTestId('campeao-card').scrollIntoViewIfNeeded();
await page.screenshot({ path: '.screenshots/camp.png', type: 'jpeg' });
await page.getByTestId('nav-avisos').click();
await page.waitForTimeout(2000);
console.log('total antes', await page.getByTestId('avisos-total-destinatarios').innerText());
await page.getByTestId('avisos-extra-remover-delivered@resend.dev').click();
await page.waitForTimeout(1500);
console.log('total depois', await page.getByTestId('avisos-total-destinatarios').innerText());
console.log('envios', await page.getByTestId('avisos-envio-item').count());
await page.screenshot({ path: '.screenshots/avisos.png', type: 'jpeg' });
console.log('ERRORS', JSON.stringify(errs));
});
