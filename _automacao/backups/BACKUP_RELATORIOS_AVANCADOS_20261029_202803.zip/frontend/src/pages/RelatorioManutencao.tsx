import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { Wrench, Clock, DollarSign, TrendingUp, CheckCircle2, Users, Truck, Fuel } from "lucide-react";
import { apiGet } from "@/lib/api";
import { PageHeader } from "@/components/common/PageHeader";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { brl } from "@/lib/format";

const COLORS = ["#10b981", "#f59e0b", "#ef4444"];

export default function RelatorioManutencao() {
  const { data: manutencoes = [] } = useQuery({ queryKey: ["manutencoes"], queryFn: () => apiGet<any[]>("/manutencoes") });
  const { data: veiculos = [] } = useQuery({ queryKey: ["veiculos"], queryFn: () => apiGet<any[]>("/veiculos") });
  const { data: fornecedores = [] } = useQuery({ queryKey: ["fornecedores"], queryFn: () => apiGet<any[]>("/fornecedores") });
  const { data: abastecimentos = [] } = useQuery({ queryKey: ["abastecimentos"], queryFn: () => apiGet<any[]>("/abastecimentos") });
  const { data: planos = [] } = useQuery({ queryKey: ["planos-manutencao"], queryFn: () => apiGet<any[]>("/planos-manutencao") });

  // 1. Cálculo de MTTR (Tempo Médio de Reparo em dias)
  const mttrData = useMemo(() => {
    const reparos = manutencoes.filter((m: any) => m.data_inicio && m.data_fim && m.data_inicio !== m.data_fim);
    if (reparos.length === 0) return { media: 0, total: 0 };

    let somaDias = 0;
    reparos.forEach((m: any) => {
      const inicio = new Date(m.data_inicio).getTime();
      const fim = new Date(m.data_fim).getTime();
      const dias = (fim - inicio) / (1000 * 60 * 60 * 24);
      somaDias += dias;
    });

    return { media: somaDias / reparos.length, total: reparos.length };
  }, [manutencoes]);

  // 2. Cálculo de CPK (Custo por KM) por Veículo
  const cpkData = useMemo(() => {
    const custosPorVeiculo: Record<string, { label: string, custo: number, km: number }> = {};
    
    manutencoes.forEach((m: any) => {
      if (m.veiculo_id && m.custo) {
        const v = veiculos.find((x: any) => x.id === m.veiculo_id);
        const kmRodado = v?.hodometro_km || 1;
        
        if (!custosPorVeiculo[m.veiculo_id]) {
          custosPorVeiculo[m.veiculo_id] = { label: m.veiculo_label, custo: 0, km: kmRodado };
        }
        custosPorVeiculo[m.veiculo_id].custo += m.custo;
      }
    });

    return Object.values(custosPorVeiculo).map(item => ({
      ...item,
      cpk: item.km > 0 ? item.custo / item.km : 0
    })).sort((a, b) => b.cpk - a.cpk);
  }, [manutencoes, veiculos]);

  // 3. Aderência ao Plano
  const aderencia = useMemo(() => {
    let ok = 0, atencao = 0, vencido = 0;
    
    planos.forEach((p: any) => {
      const v = veiculos.find((x: any) => x.id === p.veiculo_id);
      if (!v) return;
      
      const kmAtual = v.hodometro_km || 0;
      const ultimaExecucao = p.ultima_execucao_km || 0;
      const proximo = ultimaExecucao + (p.intervalo || 1);
      const falta = proximo - kmAtual;
      
      if (falta < 0) vencido++;
      else if (falta <= 5000) atencao++;
      else ok++;
    });

    return [
      { name: "Em Dia", value: ok },
      { name: "Atenção", value: atencao },
      { name: "Vencido", value: vencido },
    ];
  }, [planos, veiculos]);

  // 4. Fornecedores por Estado
  const fornecedoresPorEstado = useMemo(() => {
    const counts: Record<string, number> = {};
    fornecedores.forEach((f: any) => {
      if (f.estado) counts[f.estado] = (counts[f.estado] || 0) + 1;
    });
    return Object.entries(counts).map(([estado, quantidade]) => ({ estado, quantidade })).sort((a, b) => b.quantidade - a.quantidade).slice(0, 8);
  }, [fornecedores]);

  // 5. Custos de Manutenção Mensal
  const custosManutencao = useMemo(() => {
    const custos: Record<string, number> = {};
    manutencoes.forEach((m: any) => {
      if (m.data && m.custo) {
        const mes = m.data.slice(0, 7);
        custos[mes] = (custos[mes] || 0) + m.custo;
      }
    });
    return Object.entries(custos).sort().map(([mes, custo]) => ({ mes, custo }));
  }, [manutencoes]);

  // 6. Volume Abastecido Mensal
  const volumeAbastecimento = useMemo(() => {
    const volumes: Record<string, number> = {};
    abastecimentos.forEach((a: any) => {
      if (a.data && a.litros) {
        const mes = a.data.slice(0, 7);
        volumes[mes] = (volumes[mes] || 0) + a.litros;
      }
    });
    return Object.entries(volumes).sort().map(([mes, litros]) => ({ mes, litros }));
  }, [abastecimentos]);

  return (
    <div>
      <PageHeader
        eyebrow="Gestão"
        title="Relatório de Manutenção"
        description="Indicadores de eficiência, custo e aderência ao plano."
      />

      {/* Cards de Resumo (MTTR / CPK / Custo / Vencidos) */}
      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="glass p-4 rounded-xl flex justify-between items-center">
          <div><p className="text-xs uppercase text-slate-400">MTTR (Tempo Médio)</p><p className="text-2xl font-bold text-sky-400">{mttrData.media.toFixed(1)} dias</p></div>
          <div className="p-2 bg-sky-500/10 rounded-lg"><Clock className="size-5 text-sky-400" /></div>
        </div>
        <div className="glass p-4 rounded-xl flex justify-between items-center">
          <div><p className="text-xs uppercase text-slate-400">Total de Reparos</p><p className="text-2xl font-bold text-slate-100">{mttrData.total}</p></div>
          <div className="p-2 bg-slate-800 rounded-lg"><Wrench className="size-5 text-slate-400" /></div>
        </div>
        <div className="glass p-4 rounded-xl flex justify-between items-center">
          <div><p className="text-xs uppercase text-slate-400">Custo Total Manutenção</p><p className="text-2xl font-bold text-amber-400">{brl(manutencoes.reduce((acc: any, m: any) => acc + (m.custo || 0), 0))}</p></div>
          <div className="p-2 bg-amber-500/10 rounded-lg"><DollarSign className="size-5 text-amber-400" /></div>
        </div>
        <div className="glass p-4 rounded-xl flex justify-between items-center">
          <div><p className="text-xs uppercase text-slate-400">Planos em Atraso</p><p className="text-2xl font-bold text-rose-400">{aderencia.find(a => a.name === "Vencido")?.value || 0}</p></div>
          <div className="p-2 bg-rose-500/10 rounded-lg"><TrendingUp className="size-5 text-rose-400" /></div>
        </div>
      </div>

      {/* Linha 1 de Gráficos: Aderência e CPK */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="glass p-6 rounded-2xl">
          <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><CheckCircle2 className="size-5 text-emerald-400" /> Aderência ao Plano</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={aderencia} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5}>
                  {aderencia.map((entry, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 text-xs mt-2">
            <span className="flex items-center gap-1 text-emerald-400"><div className="size-2 rounded-full bg-emerald-400" /> Em Dia</span>
            <span className="flex items-center gap-1 text-amber-400"><div className="size-2 rounded-full bg-amber-400" /> Atenção</span>
            <span className="flex items-center gap-1 text-rose-400"><div className="size-2 rounded-full bg-rose-400" /> Vencido</span>
          </div>
        </div>

        <div className="glass p-6 rounded-2xl col-span-2">
          <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><DollarSign className="size-5 text-amber-400" /> Custo por KM Rodado (CPK)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cpkData.slice(0, 8)} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" stroke="#94a3b8" />
                <YAxis dataKey="label" type="category" width={100} stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} formatter={(value: any) => `R$ ${value.toFixed(3)}/km`} />
                <Bar dataKey="cpk" fill="#0284c7" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Linha 2 de Gráficos: Fornecedores por Estado e Volume Abastecido */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="glass p-6 rounded-2xl">
          <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><Truck className="size-5 text-sky-400" /> Top Fornecedores por Estado</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={fornecedoresPorEstado}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="estado" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
                <Bar dataKey="quantidade" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass p-6 rounded-2xl">
          <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><Fuel className="size-5 text-emerald-400" /> Volume Abastecido (Litros)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={volumeAbastecimento}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="mes" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
                <Bar dataKey="litros" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Tabela Detalhada de CPK */}
      <div className="glass overflow-hidden rounded-2xl">
        <div className="p-4 border-b border-slate-800">
          <h3 className="text-sm font-bold text-slate-200 uppercase">Detalhamento CPK por Veículo</h3>
        </div>
        <Table>
          <TableHeader>
            <TableRow className="border-slate-800">
              <TableHead className="text-xs uppercase text-slate-500">Veículo</TableHead>
              <TableHead className="text-xs uppercase text-slate-500">KM Rodado</TableHead>
              <TableHead className="text-xs uppercase text-slate-500">Custo Total</TableHead>
              <TableHead className="text-xs uppercase text-slate-500">CPK (R$/km)</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {cpkData.length === 0 ? (
              <TableRow><TableCell colSpan={4} className="text-center py-8 text-slate-500">Nenhuma manutenção registrada.</TableCell></TableRow>
            ) : (
              cpkData.map((item: any, i: number) => (
                <TableRow key={i} className="border-slate-800 hover:bg-slate-800/30">
                  <TableCell className="font-medium text-slate-200">{item.label}</TableCell>
                  <TableCell className="text-slate-400 font-mono">{item.km.toLocaleString('pt-BR')} km</TableCell>
                  <TableCell className="text-amber-400 font-mono">{brl(item.custo)}</TableCell>
                  <TableCell className="text-sky-400 font-mono font-bold">R$ {item.cpk.toFixed(3)}/km</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
