import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiGet, apiPut } from "@/lib/api";
import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Settings, CheckCircle2, XCircle } from "lucide-react";

export default function Parametrizacao() {
  const qc = useQueryClient();
  
  const [meta, setMeta] = useState("2,2");
  const [showBase, setShowBase] = useState(false);
  const [showMedidas, setShowMedidas] = useState(false);
  const [showMarcas, setShowMarcas] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);

  // Busca a configuração atual
  const { data: config, isLoading } = useQuery({
    queryKey: ["parametrizacao"],
    queryFn: () => apiGet<any>("/parametrizacao"),
  });

  // Sincroniza os dados quando carregar
  useEffect(() => {
    if (config) {
      setMeta(String(config.meta_abastecimento || "2,2").replace(".", ","));
      setShowBase(config.show_seed_base || false);
      setShowMedidas(config.show_seed_medidas || false);
      setShowMarcas(config.show_seed_marcas || false);
      setShowTemplates(config.show_seed_templates || false);
    }
  }, [config]);

  // Salvar
  const salvar = useMutation({
    mutationFn: () => {
      return apiPut("/parametrizacao", {
        meta_abastecimento: Number(meta.replace(",", ".")),
        show_seed_base: showBase,
        show_seed_medidas: showMedidas,
        show_seed_marcas: showMarcas,
        show_seed_templates: showTemplates,
      });
    },
    onSuccess: () => {
      toast.success("Parametrizações salvas!");
      qc.invalidateQueries({ queryKey: ["parametrizacao"] });
    },
    onError: (e: any) => toast.error(e.message || "Erro ao salvar.")
  });

  if (isLoading) return <div className="p-8 text-slate-400">Carregando configurações...</div>;

  return (
    <div>
      <PageHeader
        eyebrow="Administração"
        title="Parametrização"
        description="Configure os parâmetros globais do sistema."
      />

      <div className="glass p-6 rounded-2xl mt-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-sky-500/10 rounded-lg">
            <Settings className="size-5 text-sky-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-100">Configurações Globais</h3>
            <p className="text-xs text-slate-400">Metas e visibilidade de botões de setup.</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Meta de Abastecimento */}
          <div className="flex items-center justify-between py-3 border-b border-slate-800">
            <div>
              <p className="text-sm font-medium text-slate-200">Parametrização de Meta de Abastecimento</p>
              <p className="text-xs text-slate-500">Meta global em km/L.</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-400">
                <CheckCircle2 className="size-3" /> Habilitado
              </span>
              <Input 
                value={meta} 
                onChange={(e) => setMeta(e.target.value)} 
                className="w-20 h-8 text-center font-mono"
              />
            </div>
          </div>

          {/* Toggles de Setup */}
          {[
            { label: 'Exibir botão "Popular Lista Base" (Tipos de Fornecedores)', value: showBase, setter: setShowBase },
            { label: 'Exibir botão "Popular Medidas" (Medidas de Pneus)', value: showMedidas, setter: setShowMedidas },
            { label: 'Exibir botão "Popular Marcas" (Marcas de Pneus)', value: showMarcas, setter: setShowMarcas },
            { label: 'Exibir botão "Popular Templates" (Templates de Chassi)', value: showTemplates, setter: setShowTemplates },
          ].map((item, idx) => (
            <div key={idx} className="flex items-center justify-between py-3 border-b border-slate-800 last:border-0">
              <p className="text-sm font-medium text-slate-200">{item.label}</p>
              <div className="flex items-center gap-3">
                <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-bold ${item.value ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                  {item.value ? <CheckCircle2 className="size-3" /> : <XCircle className="size-3" />}
                  {item.value ? 'Habilitado' : 'Oculto'}
                </span>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => item.setter(!item.value)}
                  className={`h-7 px-3 text-xs ${item.value ? 'border-slate-700 text-slate-400 hover:bg-slate-800' : 'border-sky-500/40 text-sky-400 hover:bg-sky-500/10'}`}
                >
                  {item.value ? 'Ocultar' : 'Exibir'}
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end mt-6">
          <Button onClick={() => salvar.mutate()} disabled={salvar.isPending} className="bg-sky-600 hover:bg-sky-500">
            {salvar.isPending ? "Salvando..." : "Salvar Parametrizações"}
          </Button>
        </div>
      </div>
    </div>
  );
}