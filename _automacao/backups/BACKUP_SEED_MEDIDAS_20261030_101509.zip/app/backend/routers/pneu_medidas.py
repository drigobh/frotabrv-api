import uuid
from fastapi import APIRouter, Depends, HTTPException
from lib.db import db
from lib.security import require
from lib.dates import now_iso
from models.pneu_medidas import PneuMedidaCreate, PneuMedida

router = APIRouter(prefix="/pneu-medidas", tags=["Pneu Medidas"])

@router.get("", response_model=list[PneuMedida])
async def listar(_u: dict = Depends(require("read"))):
    docs = await db.pneu_medidas.find({}, {"_id": 0}).sort("codigo", 1).to_list(500)
    return [PneuMedida(**d) for d in docs]

@router.post("", response_model=PneuMedida, status_code=201)
async def criar(body: PneuMedidaCreate, user: dict = Depends(require("write"))):
    existente = await db.pneu_medidas.find_one({"codigo": body.codigo})
    if existente:
        raise HTTPException(409, "Esta medida já está cadastrada.")
    doc = body.model_dump()
    doc["id"] = str(uuid.uuid4())
    doc["created_at"] = now_iso()
    await db.pneu_medidas.insert_one(dict(doc))
    return PneuMedida(**doc)

@router.put("/{id}", response_model=PneuMedida)
async def atualizar(id: str, body: PneuMedidaCreate, user: dict = Depends(require("write"))):
    await db.pneu_medidas.update_one({"id": id}, {"$set": body.model_dump()})
    doc = await db.pneu_medidas.find_one({"id": id}, {"_id": 0})
    return PneuMedida(**doc)

@router.delete("/{id}")
async def excluir(id: str, _u: dict = Depends(require("delete"))):
    await db.pneu_medidas.delete_one({"id": id})
    return {"ok": True}
