import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { Wrench, AlertTriangle, CheckCircle2, FileDown, TrendingUp } from "lucide-react";
import { apiGet } from "@/lib/api";
import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const COLORS = ["#10b981", "#f59e0b", "#ef4444"];

export default function RelatorioManutencao() {
  const { data: planos = [] } = useQuery({ queryKey: ["planos-manutencao"], queryFn: () => apiGet<any[]>("/planos-manutencao") });
  const { data: veiculos = [] } = useQuery({ queryKey: ["veiculos"], queryFn: () => apiGet<any[]>("/veiculos") });
  const { data: manutencoes = [] } = useQuery({ queryKey: ["manutencoes"], queryFn: () => apiGet<any[]>("/manutencoes") });

  // 1. Calcular o status dos planos
  const planosCalculados = useMemo(() => {
    return planos.map((p: any) => {
      let ativo = veiculos.find((v: any) => v.id === p.veiculo_id);
      if (!ativo) return null;

      const kmAtual = ativo.hodometro_km || 0;
      const ultimaExecucaoKm = p.ultima_execucao_km || 0;
      const intervalo = p.intervalo || 1;

      let proximoGatilhoKm = 0;
      let faltaKm = 0;
      
      if (p.tipo_gatilho === "km") {
        proximoGatilhoKm = ultimaExecucaoKm + intervalo;
        faltaKm = proximoGatilhoKm - kmAtual;
      }

      let status = "OK";
      if (p.tipo_gatilho === "km") {
        if (faltaKm < 0) status = "Vencido";
        else if (faltaKm <= 5000) status = "Atenção";
      }

      return {
        ...p,
        ativoLabel: `${ativo.placa} - ${ativo.modelo}`,
        kmAtual,
        faltaKm,
        status
      };
    }).filter(Boolean);
  }, [planos, veiculos]);

  // 2. Dados para os Gráficos
  const aderencia = [
    { name: "Em Dia", value: planosCalculados.filter((p: any) => p.status === "OK").length },
    { name: "Atenção", value: planosCalculados.filter((p: any) => p.status === "Atenção").length },
    { name: "Vencidos", value: planosCalculados.filter((p: any) => p.status === "Vencido").length },
  ];

  const custoPorVeiculo = useMemo(() => {
    const custos: Record<string, { label: string, custo: number }> = {};
    manutencoes.forEach((m: any) => {
      if (!custos[m.veiculo_id]) {
        custos[m.veiculo_id] = { label: m.veiculo_label, custo: 0 };
      }
      custos[m.veiculo_id].custo += m.custo || 0;
    });
    return Object.values(custos).sort((a, b) => b.custo - a.custo).slice(0, 10);
  }, [manutencoes]);

  return (
    <div>
      <PageHeader
        eyebrow="Gestão"
        title="Relatório de Manutenção"
        description="Aderência ao Plano Preventivo e Custos."
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Gráfico de Pizza (Aderência) */}
        <div className="glass p-6 rounded-2xl">
          <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><CheckCircle2 className="size-5 text-emerald-400" /> Aderência ao Plano</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={aderencia} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5}>
                  {aderencia.map((entry, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 text-xs mt-2">
            <span className="flex items-center gap-1 text-emerald-400"><div className="size-2 rounded-full bg-emerald-400" /> Em Dia</span>
            <span className="flex items-center gap-1 text-amber-400"><div className="size-2 rounded-full bg-amber-400" /> Atenção</span>
            <span className="flex items-center gap-1 text-rose-400"><div className="size-2 rounded-full bg-rose-400" /> Vencido</span>
          </div>
        </div>

        {/* Gráfico de Barras (Custo por Veículo) */}
        <div className="glass p-6 rounded-2xl col-span-2">
          <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><TrendingUp className="size-5 text-amber-400" /> Top 10 Custos por Veículo</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={custoPorVeiculo} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" stroke="#94a3b8" />
                <YAxis dataKey="label" type="category" width={100} stroke="#94a3b8" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
                <Bar dataKey="custo" fill="#f59e0b" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Tabela Detalhada */}
      <div className="glass overflow-hidden rounded-2xl">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-sm font-bold text-slate-200 uppercase">Detalhamento dos Planos</h3>
          <Button variant="outline" size="sm" className="border-sky-500/40 text-sky-400"><FileDown className="size-4 mr-2" /> Exportar</Button>
        </div>
        <Table>
          <TableHeader>
            <TableRow className="border-slate-800">
              <TableHead className="text-xs uppercase text-slate-500">Ativo</TableHead>
              <TableHead className="text-xs uppercase text-slate-500">Família</TableHead>
              <TableHead className="text-xs uppercase text-slate-500">Status</TableHead>
              <TableHead className="text-xs uppercase text-slate-500">KM Faltante</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {planosCalculados.map((p: any) => (
              <TableRow key={p.id} className="border-slate-800 hover:bg-slate-800/30">
                <TableCell className="font-medium text-slate-200">{p.ativoLabel}</TableCell>
                <TableCell className="text-xs text-slate-400">{p.familia}</TableCell>
                <TableCell>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    p.status === "OK" ? "bg-emerald-500/20 text-emerald-400" : 
                    p.status === "Atenção" ? "bg-amber-500/20 text-amber-400" : 
                    "bg-rose-500/20 text-rose-400"
                  }`}>
                    {p.status}
                  </span>
                </TableCell>
                <TableCell className="text-xs font-mono text-slate-400">{p.faltaKm.toLocaleString('pt-BR')} km</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
