import { useState } from "react";
import { MapPin, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

interface MapaProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  fornecedores: any[];
}

export function MapaFornecedores({ open, onOpenChange, fornecedores }: MapaProps) {
  const [estadoSelecionado, setEstadoSelecionado] = useState("");
  const [fornecedoresMapa, setFornecedoresMapa] = useState<any[]>([]);
  const [selecionadosMapa, setSelecionadosMapa] = useState<string[]>([]);
  const [mostrarMapa, setMostrarMapa] = useState(false);


  const abrirMapaReal = () => {
    const lista = fornecedoresMapa.filter(f => selecionadosMapa.includes(f.id));
    if (lista.length === 0) return;

    // O OpenStreetMap Embed só suporta 1 marcador. 
    // Para mostrar múltiplos, vamos abrir a busca do OSM com os endereços.
    // Mas como queremos ver os PONTOS, vamos usar a URL de "direções" do OSM?
    // Não, o OSM não tem uma URL de múltiplos marcadores.
    // A melhor alternativa gratuita é usar o Google My Maps ou o próprio Google Maps via place_ids.
    
    // SOLUÇÃO: Vamos usar a URL de busca do Google Maps, mas com os endereços separados por "OR".
    // Isso faz o Google Maps mostrar resultados individuais no mapa.
    const query = lista.map(f => `${f.endereco}, ${f.cidade}, ${f.estado}`).join(' OR ');
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`, "_blank");
  };
  if (!open) return null;

  const estados = [...new Set(fornecedores.map(f => f.estado))].filter(Boolean).sort();

  const carregarFornecedoresEstado = (uf: string) => {
    setEstadoSelecionado(uf);
    setFornecedoresMapa(fornecedores.filter(f => (uf === "TODOS" || f.estado === uf) && f.endereco && f.cidade));
    setSelecionadosMapa([]);
  };

  const toggleFornecedor = (id: string) => {
    setSelecionadosMapa(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const toggleTodos = () => {
    if (selecionadosMapa.length === fornecedoresMapa.length) {
      setSelecionadosMapa([]);
    } else {
      setSelecionadosMapa(fornecedoresMapa.map(f => f.id));
    }
  };

  const abrirNoMapaReal = () => {
    const lista = fornecedoresMapa.filter(f => selecionadosMapa.includes(f.id));
    if (lista.length === 0) return;
    
    // Abre o Google Maps com os waypoints
    const enderecos = lista.map(f => encodeURIComponent(`${f.endereco}, ${f.cidade}, ${f.estado}`)).join('|');
    window.open(`https://www.google.com/maps/dir/?api=1&waypoints=${enderecos}`, "_blank");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[90vh]">
        
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <h2 className="text-lg font-bold text-slate-100">Mapa dos Fornecedores</h2>
          <button onClick={() => onOpenChange(false)} className="text-slate-400 hover:text-white">
            <X className="size-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1 flex flex-col gap-4">
          {!estadoSelecionado ? (
            <div className="flex flex-col gap-3">
              <Label className="text-slate-400">Selecione o Estado</Label>
              <div className="grid grid-cols-3 gap-2">
                <Button variant="outline" onClick={() => carregarFornecedoresEstado("TODOS")} className="h-10">
                  Todos
                </Button>
                {estados.map(uf => (
                  <Button key={uf} variant="outline" onClick={() => carregarFornecedoresEstado(uf)} className="h-10">
                    {uf} ({fornecedores.filter(f => f.estado === uf).length})
                  </Button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              <div className="flex justify-between items-center">
                <Label className="text-slate-400">Fornecedores em {estadoSelecionado} ({fornecedoresMapa.length})</Label>
                <Button variant="ghost" size="sm" onClick={toggleTodos} className="text-sky-400">Marcar/Desmarcar Todos</Button>
              </div>
              
              <div className="border border-slate-800 rounded-lg max-h-[300px] overflow-y-auto">
                {fornecedoresMapa.map(f => (
                  <label key={f.id} className="flex items-center gap-3 p-3 border-b border-slate-800 last:border-0 hover:bg-slate-800/50 cursor-pointer">
                    <input type="checkbox" checked={selecionadosMapa.includes(f.id)} onChange={() => toggleFornecedor(f.id)} className="size-4 accent-sky-500" />
                    <div>
                      <p className="text-sm font-medium text-slate-200">{f.nome}</p>
                      <p className="text-xs text-slate-500">{f.endereco}, {f.cidade} - {f.estado}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center justify-end px-6 py-4 border-t border-slate-800 gap-3 bg-slate-900/50">
          {estadoSelecionado && (
            <>
              <Button variant="outline" onClick={() => setEstadoSelecionado("")}>Voltar</Button>
              <Button onClick={abrirMapaReal} disabled={selecionadosMapa.length === 0} className="bg-emerald-600 hover:bg-emerald-500">
                <MapPin className="size-4 mr-2" /> Abrir no Mapa ({selecionadosMapa.length})
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
