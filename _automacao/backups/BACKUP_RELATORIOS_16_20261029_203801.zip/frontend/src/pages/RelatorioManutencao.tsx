import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, PieChart, Pie, Cell, AreaChart, Area 
} from "recharts";
import { 
  Wrench, Clock, DollarSign, TrendingUp, CheckCircle2, Truck, 
  AlertTriangle, Users, FileDown, ShieldAlert, Target, RotateCcw
} from "lucide-react";
import { apiGet } from "@/lib/api";
import { PageHeader } from "@/components/common/PageHeader";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { brl } from "@/lib/format";

const COLORS = ["#10b981", "#f59e0b", "#ef4444", "#0284c7", "#8b5cf6"];

export default function RelatorioManutencao() {
  const { data: manutencoes = [] } = useQuery({ queryKey: ["manutencoes"], queryFn: () => apiGet<any[]>("/manutencoes") });
  const { data: veiculos = [] } = useQuery({ queryKey: ["veiculos"], queryFn: () => apiGet<any[]>("/veiculos") });
  const { data: fornecedores = [] } = useQuery({ queryKey: ["fornecedores"], queryFn: () => apiGet<any[]>("/fornecedores") });
  const { data: planos = [] } = useQuery({ queryKey: ["planos-manutencao"], queryFn: () => apiGet<any[]>("/planos-manutencao") });

  const [abaAtiva, setAbaAtiva] = useState("cpk");

  const abas = [
    { id: "cpk", label: "CPK (Custo/KM)" },
    { id: "mtbf", label: "MTBF (Entre Falhas)" },
    { id: "mttr", label: "MTTR (Tempo Reparo)" },
    { id: "pecas", label: "Consumo de Peças" },
    { id: "aderencia", label: "Aderência Preventiva" },
    { id: "reincidencia", label: "Reincidência" },
    { id: "motorista", label: "Custo por Motorista" },
    { id: "fornecedor", label: "Ranking Fornecedores" },
  ];

  // 1. CPK (Custo por KM)
  const cpkData = useMemo(() => {
    const custos: Record<string, { label: string, custo: number, km: number }> = {};
    manutencoes.forEach((m: any) => {
      if (m.veiculo_id && m.custo) {
        const v = veiculos.find((x: any) => x.id === m.veiculo_id);
        if (!custos[m.veiculo_id]) custos[m.veiculo_id] = { label: m.veiculo_label, custo: 0, km: v?.hodometro_km || 1 };
        custos[m.veiculo_id].custo += m.custo;
      }
    });
    return Object.values(custos).map(item => ({ ...item, cpk: item.custo / item.km })).sort((a, b) => b.cpk - a.cpk);
  }, [manutencoes, veiculos]);

  // 2. MTBF (Tempo Entre Falhas - Simulado com base no tempo entre manutenções corretivas)
  const mtbfData = useMemo(() => {
    const falhas: Record<string, number> = {};
    manutencoes.filter((m: any) => m.tipo === "Corretiva").forEach((m: any) => {
      falhas[m.veiculo_id] = (falhas[m.veiculo_id] || 0) + 1;
    });
    return Object.entries(falhas).map(([id, count]) => ({
      label: veiculos.find((v: any) => v.id === id)?.placa || id,
      falhas: count
    })).sort((a, b) => b.falhas - a.falhas);
  }, [manutencoes, veiculos]);

  // 3. MTTR (Tempo Médio de Reparo)
  const mttrData = useMemo(() => {
    const reparos = manutencoes.filter((m: any) => m.data_inicio && m.data_fim && m.data_inicio !== m.data_fim);
    let somaDias = 0;
    reparos.forEach((m: any) => {
      somaDias += (new Date(m.data_fim).getTime() - new Date(m.data_inicio).getTime()) / (1000 * 60 * 60 * 24);
    });
    return { media: reparos.length > 0 ? somaDias / reparos.length : 0, total: reparos.length };
  }, [manutencoes]);

  // 4. Consumo de Peças (Agrupado por Descrição)
  const pecasData = useMemo(() => {
    const pecas: Record<string, number> = {};
    manutencoes.forEach((m: any) => {
      if (m.pecas_substituidas) {
        pecas[m.pecas_substituidas] = (pecas[m.pecas_substituidas] || 0) + 1;
      }
    });
    return Object.entries(pecas).map(([nome, quantidade]) => ({ nome, quantidade })).sort((a, b) => b.quantidade - a.quantidade).slice(0, 8);
  }, [manutencoes]);

  // 5. Aderência Preventiva (Baseado nos planos cadastrados)
  const aderenciaData = useMemo(() => {
    let ok = 0, atencao = 0, vencido = 0;
    planos.forEach((p: any) => {
      const v = veiculos.find((x: any) => x.id === p.veiculo_id);
      if (!v) return;
      const falta = (p.ultima_execucao_km || 0) + (p.intervalo || 1) - (v.hodometro_km || 0);
      if (falta < 0) vencido++;
      else if (falta <= 5000) atencao++;
      else ok++;
    });
    return [{ name: "Em Dia", value: ok }, { name: "Atenção", value: atencao }, { name: "Vencido", value: vencido }];
  }, [planos, veiculos]);

  // 6. Reincidência (Veículos com mais de 1 manutenção no mesmo mês)
  const reincidenciaData = useMemo(() => {
    const contagem: Record<string, number> = {};
    manutencoes.forEach((m: any) => {
      const chave = `${m.veiculo_id}-${m.data?.slice(0, 7)}`;
      contagem[chave] = (contagem[chave] || 0) + 1;
    });
    return Object.entries(contagem).filter(([_, count]) => count > 1).map(([chave, count]) => {
      const [veiculoId, mes] = chave.split("-");
      return { veiculo: veiculos.find((v: any) => v.id === veiculoId)?.placa || veiculoId, mes, quantidade: count };
    });
  }, [manutencoes, veiculos]);

  // 7. Custo por Motorista (Agrupado por veículo como proxy)
  const custoMotoristaData = useMemo(() => {
    const custos: Record<string, number> = {};
    manutencoes.forEach((m: any) => {
      if (m.veiculo_label && m.custo) {
        const motorista = m.veiculo_label.split(" ")[0];
        custos[motorista] = (custos[motorista] || 0) + m.custo;
      }
    });
    return Object.entries(custos).map(([nome, custo]) => ({ nome, custo })).sort((a, b) => b.custo - a.custo).slice(0, 5);
  }, [manutencoes]);

  // 9. Ranking de Fornecedores (Por Custo)
  const fornecedorData = useMemo(() => {
    const custos: Record<string, number> = {};
    manutencoes.forEach((m: any) => {
      if (m.oficina && m.custo) {
        custos[m.oficina] = (custos[m.oficina] || 0) + m.custo;
      }
    });
    return Object.entries(custos).map(([nome, custo]) => ({ nome, custo })).sort((a, b) => b.custo - a.custo).slice(0, 5);
  }, [manutencoes]);

  const renderAba = () => {
    switch (abaAtiva) {
      case "cpk":
        return (
          <div className="space-y-6">
            <div className="glass p-6 rounded-2xl">
              <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><DollarSign className="size-5 text-amber-400" /> Top 10 CPK (Custo por KM)</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={cpkData.slice(0, 10)} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis type="number" stroke="#94a3b8" />
                    <YAxis dataKey="label" type="category" width={100} stroke="#94a3b8" tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} formatter={(v: any) => `R$ ${v.toFixed(3)}/km`} />
                    <Bar dataKey="cpk" fill="#0284c7" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <TabelaDados colunas={["Veículo", "KM Rodado", "Custo Total", "CPK"]} dados={cpkData.map(i => [i.label, `${i.km.toLocaleString('pt-BR')} km`, brl(i.custo), `R$ ${i.cpk.toFixed(3)}/km`])} />
          </div>
        );
      case "mtbf":
        return (
          <div className="space-y-6">
            <div className="glass p-6 rounded-2xl">
              <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><ShieldAlert className="size-5 text-rose-400" /> Veículos com Mais Falhas (Corretivas)</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={mtbfData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="label" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" allowDecimals={false} />
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
                    <Bar dataKey="falhas" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <TabelaDados colunas={["Veículo", "Qtd. Falhas"]} dados={mtbfData.map(i => [i.label, i.falhas])} />
          </div>
        );
      case "mttr":
        return (
          <div className="glass p-6 rounded-2xl text-center space-y-4">
            <h3 className="text-lg font-bold text-slate-100 mb-2 flex items-center justify-center gap-2"><Clock className="size-5 text-sky-400" /> MTTR (Tempo Médio de Reparo)</h3>
            <p className="text-6xl font-bold text-sky-400">{mttrData.media.toFixed(1)} <span className="text-2xl text-slate-400">dias</span></p>
            <p className="text-sm text-slate-400">Calculado com base em {mttrData.total} manutenções concluídas (com data de início e fim).</p>
          </div>
        );
      case "pecas":
        return (
          <div className="space-y-6">
            <div className="glass p-6 rounded-2xl">
              <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><Wrench className="size-5 text-indigo-400" /> Top Peças/Serviços Substituídos</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={pecasData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis type="number" stroke="#94a3b8" allowDecimals={false} />
                    <YAxis dataKey="nome" type="category" width={150} stroke="#94a3b8" tick={{ fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
                    <Bar dataKey="quantidade" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <TabelaDados colunas={["Peça/Serviço", "Qtd. Trocas"]} dados={pecasData.map(i => [i.nome, i.quantidade])} />
          </div>
        );
      case "aderencia":
        return (
          <div className="glass p-6 rounded-2xl flex flex-col items-center">
            <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><CheckCircle2 className="size-5 text-emerald-400" /> Aderência ao Plano Preventivo</h3>
            <div className="h-72 w-full max-w-md">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={aderenciaData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5}>
                    {aderenciaData.map((entry, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex gap-6 mt-4 text-sm">
              {aderenciaData.map((item, i) => (
                <span key={i} className="flex items-center gap-2" style={{ color: COLORS[i] }}><div className="size-3 rounded-full" style={{ backgroundColor: COLORS[i] }} /> {item.name}: {item.value}</span>
              ))}
            </div>
          </div>
        );
      case "reincidencia":
        return (
          <div className="space-y-6">
            <div className="glass p-6 rounded-2xl">
              <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><RotateCcw className="size-5 text-rose-400" /> Veículos com Reincidência (Mais de 1 manutenção no mesmo mês)</h3>
              <TabelaDados colunas={["Veículo", "Mês", "Qtd. Manutenções"]} dados={reincidenciaData.map(i => [i.veiculo, i.mes, i.quantidade])} vazio="Nenhuma reincidência encontrada." />
            </div>
          </div>
        );
      case "motorista":
        return (
          <div className="space-y-6">
            <div className="glass p-6 rounded-2xl">
              <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><Users className="size-5 text-purple-400" /> Top 5 Veículos com Maior Custo (Proxy de Motorista)</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={custoMotoristaData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="nome" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" tickFormatter={(v: any) => brl(v)} />
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} formatter={(v: any) => brl(v)} />
                    <Bar dataKey="custo" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        );
      case "fornecedor":
        return (
          <div className="space-y-6">
            <div className="glass p-6 rounded-2xl">
              <h3 className="text-lg font-bold text-slate-100 mb-4 flex items-center gap-2"><Target className="size-5 text-sky-400" /> Top 5 Fornecedores por Custo de Manutenção</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={fornecedorData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="nome" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" tickFormatter={(v: any) => brl(v)} />
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} formatter={(v: any) => brl(v)} />
                    <Bar dataKey="custo" fill="#10b981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <TabelaDados colunas={["Fornecedor", "Custo Total"]} dados={fornecedorData.map(i => [i.nome, brl(i.custo)])} />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Gestão"
        title="Relatórios de Manutenção"
        description="Painel completo de indicadores e inteligência da frota."
      />

      {/* Navegação por Abas */}
      <div className="flex gap-2 overflow-x-auto pb-2 mb-6 border-b border-slate-800">
        {abas.map(aba => (
          <button
            key={aba.id}
            onClick={() => setAbaAtiva(aba.id)}
            className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors whitespace-nowrap ${
              abaAtiva === aba.id 
                ? "bg-slate-800 text-sky-400 border-b-2 border-sky-400" 
                : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
            }`}
          >
            {aba.label}
          </button>
        ))}
      </div>

      {/* Renderização do Conteúdo da Aba */}
      {renderAba()}
    </div>
  );
}

// Componente Auxiliar para Tabelas
function TabelaDados({ colunas, dados, vazio = "Nenhum dado encontrado." }: { colunas: string[], dados: any[][], vazio?: string }) {
  if (dados.length === 0) return <div className="glass p-6 rounded-2xl text-center text-slate-500">{vazio}</div>;
  return (
    <div className="glass overflow-hidden rounded-2xl mt-4">
      <Table>
        <TableHeader>
          <TableRow className="border-slate-800">
            {colunas.map(c => <TableHead key={c} className="text-xs uppercase text-slate-500">{c}</TableHead>)}
          </TableRow>
        </TableHeader>
        <TableBody>
          {dados.map((linha, i) => (
            <TableRow key={i} className="border-slate-800 hover:bg-slate-800/30">
              {linha.map((celula, j) => <TableCell key={j} className="text-slate-300">{celula}</TableCell>)}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
