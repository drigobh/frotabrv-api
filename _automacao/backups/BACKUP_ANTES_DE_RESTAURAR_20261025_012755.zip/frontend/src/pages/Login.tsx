import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { apiPost } from "@/lib/api";
import { Truck, Loader2 } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // A chamada à API já retorna o token
      const data = await apiPost<{ token: string }>("/auth/login", { email, senha });
      
      if (data && data.token) {
        localStorage.setItem("token", data.token);
        localStorage.setItem("auth_token", data.token);
        toast.success("Login realizado com sucesso!");
        
        // O window.location.href recarrega a página inteira, 
        // limpando o cache do React Query e evitando o loop do 401
        window.location.href = "/";
      } else {
        toast.error("Token não retornado pelo servidor.");
      }
    } catch (error: any) {
      toast.error(error.message || "E-mail ou senha inválidos.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen w-screen items-center justify-center bg-slate-950">
      <div className="w-full max-w-md glass rounded-2xl p-8 space-y-6">
        <div className="text-center flex flex-col items-center">
          <div className="size-12 rounded-xl bg-sky-500 flex items-center justify-center mb-3">
            <Truck className="size-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-slate-100">Bravus</h1>
          <p className="text-sm text-slate-400">Gestão de Frotas</p>
        </div>
        
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="text-xs font-medium text-slate-400 mb-1 block">E-mail</label>
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-100 focus:outline-none focus:border-sky-500 transition-colors"
              placeholder="seu@email.com"
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-400 mb-1 block">Senha</label>
            <input 
              type="password" 
              value={senha} 
              onChange={(e) => setSenha(e.target.value)}
              className="w-full p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-100 focus:outline-none focus:border-sky-500 transition-colors"
              placeholder="••••••••"
              required
              autoComplete="current-password"
            />
          </div>
          <button 
            type="submit" 
            disabled={loading}
            className="w-full py-2.5 bg-sky-600 text-white rounded-lg font-medium hover:bg-sky-500 transition-colors flex items-center justify-center gap-2"
          >
            {loading ? <Loader2 className="size-4 animate-spin" /> : null}
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>
      </div>
    </div>
  );
}
