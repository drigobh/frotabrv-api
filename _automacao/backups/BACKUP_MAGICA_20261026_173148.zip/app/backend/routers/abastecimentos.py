from fastapi import APIRouter, Depends, HTTPException, Request, Query
from lib.dates import now_iso
from lib.db import db
from lib.security import require
from models.abastecimentos import Abastecimento, AbastecimentoCreate
import uuid
from datetime import datetime

router = APIRouter(prefix="/abastecimentos", tags=["abastecimentos"])

@router.get("", response_model=None)
async def listar(
    veiculo_id: str = Query(None),
    mes: str = Query(None),
    motorista_id: str = Query(None),
    posto: str = Query(None),
    produto: str = Query(None),
    origem: str = Query(None),
    _u: dict = Depends(require("read"))
):
    query = {}
    
    if veiculo_id and veiculo_id != "__all__":
        query["veiculo_id"] = veiculo_id
    if mes:
        query["data"] = {"$regex": f"^{mes}"}
    if motorista_id and motorista_id != "__all__":
        query["motorista_id"] = motorista_id
    if posto:
        query["posto"] = {"$regex": posto, "$options": "i"}
    if produto:
        query["produto"] = {"$regex": produto, "$options": "i"}
    if origem and origem != "__all__":
        query["origem"] = origem
        
    docs = await db.abastecimentos.find(query, {"_id": 0}).sort("data", -1).to_list(5000)
    return docs

@router.get("/ultimo-km/{veiculo_id}")
async def ultimo_km(veiculo_id: str, _u: dict = Depends(require("read"))):
    veiculo = await db.veiculos.find_one({"id": veiculo_id}, {"_id": 0})
    if not veiculo:
        raise HTTPException(404, "Veículo não encontrado")
    
    ultimo_abast = await db.abastecimentos.find_one(
        {"veiculo_id": veiculo_id}, 
        {"_id": 0},
        sort=[("km", -1)]
    )
    
    km_veiculo = veiculo.get("hodometro_km", 0)
    km_abast = ultimo_abast["km"] if ultimo_abast else 0
    
    return {"ultimo_km": max(km_veiculo, km_abast)}

def limpar_km(val):
    if val is None: return 0
    s = str(val).strip()
    if s.endswith(".0"): s = s[:-2]
    s = "".join(filter(str.isdigit, s))
    return int(s) if s else 0

def calcular_km(km_atual, litros, produto, ultimo, veiculo):
    km_atual = limpar_km(km_atual)
    km_rodados = None
    media_km_l = None

    def normalizar_km(val_str):
        val = limpar_km(val_str)
        # Se o hodômetro for menor que 10000 (ex: 290, 304), multiplica por 1000 (290000, 304000)
        if 0 < val < 10000:
            val = val * 1000
        return val

    if ultimo and ultimo.get("km"):
        ultimo_km = normalizar_km(ultimo["km"])
        km_rodados = km_atual - ultimo_km
    elif veiculo.get("hodometro_km") is not None:
        veiculo_km = normalizar_km(veiculo["hodometro_km"])
        km_rodados = km_atual - veiculo_km

    # Trava de segurança
    if km_rodados is not None:
        if km_rodados <= 0 or km_rodados > 50000:
            km_rodados = None
        elif km_rodados > 0 and litros > 0 and "ARLA" not in (produto or "").upper():
            media_km_l = km_rodados / litros
        elif km_rodados == 0:
            media_km_l = 0

    return km_rodados, media_km_l

@router.post("/importar", response_model=None, status_code=201)
async def importar_pdf(body: dict, request: Request, user: dict = Depends(require("write"))):
    placa_limpa = body.get("placa", "").strip().upper()
    
    veiculo = await db.veiculos.find_one({"placa": placa_limpa}, {"_id": 0})
    if not veiculo:
        raise HTTPException(status_code=404, detail=f"Veículo com placa {placa_limpa} não encontrado.")

    litros = body.get("litros") or 0
    preco_litro = body.get("preco_litro") or 0
    data_recebida = body.get("data")
    km_atual = body.get("km") or 0
    produto = body.get("produto", "DIESEL").upper()

    try:
        if "/" in data_recebida:
            data_abast = datetime.strptime(data_recebida, "%d/%m/%Y").strftime("%Y-%m-%d")
        else:
            data_abast = data_recebida
    except:
        data_abast = data_recebida

    ultimo = await db.abastecimentos.find_one(
        {"veiculo_id": veiculo["id"], "data": {"$lt": data_abast}},
        {"_id": 0},
        sort=[("data", -1)]
    )

    km_rodados, media_km_l = calcular_km(km_atual, litros, produto, ultimo, veiculo)

    valor_total = body.get("valor_total")
    if not valor_total:
        valor_total = litros * preco_litro
    valor_total = round(valor_total, 2)

    acoplamento = await db.acoplamentos.find_one(
        {"veiculo_id": veiculo["id"]},
        {"_id": 0},
        sort=[("created_at", -1)]
    )
        
    motorista_id = acoplamento.get("motorista_id") if acoplamento else None
    motorista_label = None
    if motorista_id:
        mot = await db.motoristas.find_one({"id": motorista_id}, {"_id": 0})
        motorista_label = mot["nome"] if mot else None

    doc = {
        "id": str(uuid.uuid4()),
        "data": data_abast,
        "veiculo_id": veiculo["id"],
        "veiculo_label": f"{veiculo['placa']} · {veiculo['modelo']}",
        "motorista_id": motorista_id,
        "motorista_label": motorista_label,
        "litros": litros,
        "preco_litro": preco_litro,
        "valor_total": valor_total,
        "posto": body.get("fornecedor") or "Importado",
        "km": km_atual,
        "km_rodados": km_rodados,
        "media_km_l": media_km_l,
        "origem": body.get("origem", "excel"),
        "produto": produto,
        "numero_nf": body.get("numero_nf"),
        "chave_nfe": body.get("chave_nfe"),
        "codigo_transacao": body.get("codigo_transacao"),
        "hora": body.get("hora"),
        "cnpj": body.get("cnpj"),
        "cidade": body.get("cidade"),
        "estado": body.get("estado"),
        "fornecedor": body.get("fornecedor"),
        "created_by": user.get("id", "sistema"),
        "created_by_name": user.get("nome", user.get("email", "Sistema")),
        "created_at": now_iso()
    }

    await db.abastecimentos.insert_one(doc)
    if km_atual > 0:
        await db.veiculos.update_one({"id": veiculo["id"]}, {"$set": {"hodometro_km": km_atual}})
    doc.pop("_id", None)
    return doc

@router.post("", response_model=Abastecimento, status_code=201)
async def criar(body: dict, request: Request, user: dict = Depends(require("write"))):
    veiculo_id = body.get("veiculo_id")
    if not veiculo_id:
        raise HTTPException(400, "Veículo é obrigatório")
    
    veiculo = await db.veiculos.find_one({"id": veiculo_id}, {"_id": 0})
    if not veiculo:
        raise HTTPException(404, "Veículo não encontrado")

    # Busca o último abastecimento para calcular KM
    ultimo = await db.abastecimentos.find_one(
        {"veiculo_id": veiculo_id, "data": {"$lt": body.get("data")}},
        {"_id": 0},
        sort=[("data", -1)]
    )

    litros = float(body.get("litros") or 0)
    preco_litro = float(body.get("preco_litro") or 0)
    km_atual = float(body.get("km") or 0) # AQUI ESTAVA O ERRO, AGORA ESTÁ DEFINIDO

    km_rodados = None
    media_km_l = None

    if ultimo and ultimo.get("km") and km_atual > ultimo["km"]:
        km_rodados = km_atual - ultimo["km"]
        if litros > 0:
            media_km_l = km_rodados / litros

    # Monta o documento
    doc = {k: v for k, v in body.items() if v is not None}
    doc["id"] = str(uuid.uuid4())
    doc["veiculo_label"] = f"{veiculo['placa']} · {veiculo.get('modelo', '')}"
    doc["valor_total"] = round(litros * preco_litro, 2)
    doc["km_rodados"] = km_rodados
    doc["media_km_l"] = media_km_l
    doc["created_by"] = user.get("id", "sistema")
    doc["created_by_name"] = user.get("nome", user.get("email", "Sistema"))
    doc["created_at"] = now_iso()
    doc["origem"] = doc.get("origem", "manual")

    if body.get("motorista_id"):
        mot = await db.motoristas.find_one({"id": body["motorista_id"]}, {"_id": 0})
        doc["motorista_label"] = mot["nome"] if mot else None
    else:
        doc["motorista_label"] = None

    # Verifica se a nota já foi importada (Duplicidade)
    chave_nfe_recebida = body.get("chave_nfe")
    numero_nf_recebido = body.get("numero_nf")
    
    if chave_nfe_recebida:
        existente = await db.abastecimentos.find_one({"chave_nfe": chave_nfe_recebida})
        if existente:
            raise HTTPException(409, "Esta nota fiscal já foi importada (Chave NF-e duplicada).")
    elif numero_nf_recebido and body.get("cnpj"):
        existente = await db.abastecimentos.find_one({"numero_nf": numero_nf_recebido, "cnpj": body.get("cnpj")})
        if existente:
            raise HTTPException(409, "Esta nota fiscal já foi importada (Número da NF e CNPJ duplicados).")

    await db.abastecimentos.insert_one(doc)
    doc.pop("_id", None)
    return doc
@router.put("/{id}", response_model=Abastecimento)
async def atualizar(id: str, body: AbastecimentoCreate, request: Request, user: dict = Depends(require("write"))):
    veiculo = await db.veiculos.find_one({"id": body.veiculo_id}, {"_id": 0})
    if not veiculo:
        raise HTTPException(404, "Veículo não encontrado")
        
    ultimo = await db.abastecimentos.find_one(
        {"veiculo_id": body.veiculo_id, "data": {"$lt": body.data}, "id": {"$ne": id}},
        {"_id": 0},
        sort=[("data", -1)]
    )
    
    km_rodados, media_km_l = calcular_km(body.km, body.litros, body.produto, ultimo, veiculo)

    doc = body.model_dump()
    doc["veiculo_label"] = f"{veiculo['placa']} · {veiculo['modelo']}"
    doc["valor_total"] = round(body.litros * body.preco_litro, 2)
    doc["km_rodados"] = km_rodados
    doc["media_km_l"] = media_km_l
    
    if body.motorista_id:
        mot = await db.motoristas.find_one({"id": body.motorista_id}, {"_id": 0})
        doc["motorista_label"] = mot["nome"] if mot else None
    else:
        doc["motorista_label"] = None
        
    if body.combustivel_id and not body.produto:
        comb = await db.combustiveis.find_one({"id": body.combustivel_id}, {"_id": 0})
        doc["produto"] = comb["nome"] if comb else "Diesel S-10"

    await db.abastecimentos.update_one({"id": id}, {"$set": doc})
    doc["id"] = id
    doc["created_by"] = user["id"]
    doc["created_at"] = now_iso()
    return doc

@router.delete("/{id}")
async def excluir(id: str, _u: dict = Depends(require("delete"))):
    await db.abastecimentos.delete_one({"id": id})
    return {"ok": True}
