import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Package } from "lucide-react";

export default function Estoque() {
  return (
    <div>
      <PageHeader 
        eyebrow="Operação" 
        title="Estoque de Peças" 
        description="Controle de almoxarifado." 
        actions={<Button><Package className="size-4 mr-2" /> Nova Peça</Button>} 
      />
      <div className="glass rounded-2xl p-6">
        <h1 className="text-2xl font-bold text-emerald-400 mb-4">✅ ESTOQUE ABRIU!</h1>
        <p className="text-slate-300">Se você está vendo esta mensagem, a rota está correta. Agora podemos reconstruir a tabela e os cards com calma.</p>
      </div>
    </div>
  );
}
