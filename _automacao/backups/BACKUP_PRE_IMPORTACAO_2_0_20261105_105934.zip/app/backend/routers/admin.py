from fastapi import APIRouter, Depends, HTTPException
from lib.db import db
from lib.security import require
import json
import os
from datetime import datetime

router = APIRouter(prefix="/api/admin", tags=["Admin"])

@router.post("/limpar-base")
async def limpar_base(colecao: str, user: dict = Depends(require("admin"))):
    colecoes_permitidas = ["veiculos", "carretas", "motoristas", "acoplamentos", "abastecimentos", "fornecedores"]
    
    if colecao not in colecoes_permitidas:
        raise HTTPException(status_code=400, detail="Coleção inválida.")
    
    # Backup automático
    dados = await db[colecao].find({}, {"_id": 0}).to_list(None)
    nome_arquivo = None
    
    if dados:
        pasta_backup = os.path.join(os.getcwd(), "backups")
        os.makedirs(pasta_backup, exist_ok=True)
        nome_arquivo = f"backup_{colecao}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        caminho_arquivo = os.path.join(pasta_backup, nome_arquivo)
        
        with open(caminho_arquivo, "w", encoding="utf-8") as f:
            json.dump(dados, f, ensure_ascii=False, indent=2, default=str)
            
        print(f"Backup salvo em: {caminho_arquivo}")

    result = await db[colecao].delete_many({})
    
    return {
        "mensagem": f"Base da coleção '{colecao}' limpa com sucesso.",
        "quantidade_apagada": result.deleted_count,
        "backup": nome_arquivo if dados else None
    }
