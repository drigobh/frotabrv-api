import { CadastroTable } from "@/components/cadastros/CadastroTable";
import type { Carreta } from "@/types/cadastros";

const TIPOS_CARRETA = [
  { value: "Bau", label: "Bau" },
  { value: "Sider", label: "Sider" },
  { value: "Graneleiro", label: "Graneleiro" },
  { value: "Frigorifico", label: "Frigorífico" },
  { value: "Tanque", label: "Tanque" },
  { value: "Prancha", label: "Prancha" },
  { value: "Cacamba", label: "Caçamba" },
  { value: "Porta-conteiner", label: "Porta-contêiner" },
];

const columns = [
  { key: "codigo", label: "Código" },
  { key: "placa", label: "Placa" },
  { key: "modelo", label: "Modelo" },
  { key: "ano", label: "Ano" },
  { key: "hodometro_km", label: "KM" },
  { key: "tipo", label: "Tipo" },
  { key: "observacoes", label: "Observações" },
];

const fields = [
  { key: "codigo", label: "Código", type: "text", placeholder: "CR-001", required: true },
  { key: "placa", label: "Placa", type: "text", placeholder: "ABC-1234" },
  { key: "modelo", label: "Modelo", type: "text", placeholder: "Ex: Graneleiro" },
  { key: "ano", label: "Ano", type: "number", placeholder: "2024" },
  { key: "hodometro_km", label: "Hodômetro (KM)", type: "number", placeholder: "0" },
  { key: "tipo", label: "Tipo", type: "select", options: TIPOS_CARRETA, required: true },
  { key: "observacoes", label: "Observações", type: "textarea", placeholder: "Opcional" },
];

export default function Carretas() {
  return (
    <CadastroTable<Carreta>
      title="Carretas"
      description="Semirreboques da frota. Inative em vez de excluir."
      endpoint="/carretas"
      entityLabel="carreta"
      testPrefix="carreta"
      columns={columns}
      fields={fields}
      searchKeys={["codigo", "tipo", "placa", "modelo"]}
    />
  );
}
