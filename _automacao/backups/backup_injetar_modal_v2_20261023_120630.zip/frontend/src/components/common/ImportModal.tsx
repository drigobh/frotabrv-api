import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle2 } from "lucide-react";

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  progress: { total: number; current: number; errors: any[] } | null;
};

export function ImportModal({ open, onOpenChange, progress }: Props) {
  if (!progress) return null;

  const isFinished = progress.current >= progress.total;
  const hasErrors = progress.errors.length > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Importando Planilha</DialogTitle>
          <DialogDescription>
            {!isFinished ? "Por favor, aguarde enquanto processamos os registros..." : 
             hasErrors ? "Importação finalizada com erros." : "Importação concluída com sucesso!"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400">Progresso</span>
            <span className="font-mono text-slate-200">{progress.current} / {progress.total}</span>
          </div>
          
          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
            <div 
              className={`h-full transition-all duration-300 ${isFinished && !hasErrors ? 'bg-emerald-500' : 'bg-sky-500'}`} 
              style={{ width: `${(progress.current / progress.total) * 100}%` }} 
            />
          </div>

          {isFinished && !hasErrors && (
            <div className="flex items-center gap-2 text-emerald-400 bg-emerald-500/10 p-3 rounded-lg">
              <CheckCircle2 className="size-5" />
              <span className="text-sm font-medium">Todos os registros foram importados com sucesso!</span>
            </div>
          )}

          {hasErrors && (
            <div className="mt-4">
              <h4 className="text-sm font-semibold text-red-400 mb-2 flex items-center gap-2">
                <AlertTriangle className="size-4" /> Erros encontrados ({progress.errors.length})
              </h4>
              <div className="max-h-40 overflow-y-auto rounded-md border border-slate-800 bg-slate-950 p-2">
                <ul className="space-y-1 text-xs">
                  {progress.errors.map((err, idx) => (
                    <li key={idx} className="text-slate-300">
                      <span className="font-mono text-slate-500">Linha {err.linha}</span> - 
                      <span className="text-red-300 font-medium mx-1">{err.placa}</span>: 
                      <span className="text-slate-400">{err.erro}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {isFinished ? (
            <Button onClick={() => onOpenChange(false)}>Fechar</Button>
          ) : (
            <Button disabled variant="outline">Processando...</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}