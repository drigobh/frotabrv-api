import { Link, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, Fuel, Wrench, Truck, Users, Car, 
  Settings, Package, Disc, Activity, BarChart3, 
  FileText, DollarSign, LogOut, ChevronRight, Briefcase
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useMe } from "@/hooks/useSession";
import { Button } from "@/components/ui/button";

const GROUPS = [
  {
    label: "Operação",
    items: [
      { label: "Dashboard", icon: LayoutDashboard, path: "/" },
      { label: "Abastecimentos", icon: Fuel, path: "/abastecimentos" },
      { label: "Manutenções", icon: Wrench, path: "/manutencoes" },
      { label: "Pneus", icon: Disc, path: "/operacao/pneus" },
      { label: "Monitoramento", icon: Activity, path: "/operacao/monitoramento" },
      { label: "Estoque", icon: Package, path: "/operacao/estoque" },
    ],
  },
  {
    label: "Cadastros",
    items: [
      { label: "Veículos", icon: Truck, path: "/cadastros/veiculos" },
      { label: "Carretas", icon: Car, path: "/cadastros/carretas" },
      { label: "Motoristas", icon: Users, path: "/cadastros/motoristas" },
      { label: "Combustíveis", icon: Fuel, path: "/cadastros/combustiveis" },
      { label: "Fornecedores", icon: Briefcase, path: "/cadastros/fornecedores" },
      { label: "Acoplamentos", icon: Settings, path: "/cadastros/acoplamentos" },
      { label: "Base", icon: FileText, path: "/admin/base" },
    ],
  },
  {
    label: "Gestão",
    items: [
      { label: "Financeiro", icon: DollarSign, path: "/financeiro" },
      { label: "Performance de Fornecedores", icon: BarChart3, path: "/relatorios/fornecedores" },
      { label: "Relatórios", icon: FileText, path: "/relatorios" },
    ],
  },
];

export function Sidebar() {
  const { pathname } = useLocation();
  const { data: me } = useMe();

  return (
    <aside className="w-64 border-r border-slate-800 bg-slate-950/50 flex flex-col h-screen overflow-y-auto">
      <div className="p-6 flex items-center gap-3 border-b border-slate-800/50">
        <div className="size-8 rounded-lg bg-sky-500 flex items-center justify-center text-white font-bold text-lg">F</div>
        <span className="font-bold text-lg text-slate-100 tracking-tight">FrotaBRV</span>
      </div>

      <div className="flex-1 py-4 space-y-6">
        {GROUPS.map((group) => (
          <div key={group.label}>
            <p className="px-6 text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-2">{group.label}</p>
            <nav className="space-y-1 px-3">
              {group.items.map((item) => {
                const isActive = pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors group",
                      isActive 
                        ? "bg-sky-500/10 text-sky-400 font-medium" 
                        : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
                    )}
                  >
                    <item.icon className={cn("size-4", isActive ? "text-sky-400" : "text-slate-500 group-hover:text-slate-300")} />
                    <span className="flex-1 truncate">{item.label}</span>
                    {isActive && <ChevronRight className="size-3 text-sky-400" />}
                  </Link>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-slate-800/50">
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-slate-900/50 mb-2">
          <div className="size-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-300">
            {me?.nome?.charAt(0).toUpperCase() || "U"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-slate-200 truncate">{me?.nome || "Usuário"}</p>
            <p className="text-[10px] text-slate-500 truncate">{me?.perfil || "Acesso"}</p>
          </div>
        </div>
        <Button variant="ghost" className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-500/10 h-9 px-3" onClick={() => { localStorage.removeItem("token"); window.location.href = "/login"; }}>
          <LogOut className="size-4 mr-2" /> Sair
        </Button>
      </div>
    </aside>
  );
}
